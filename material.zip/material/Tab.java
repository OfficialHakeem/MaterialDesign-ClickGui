package tomorrow.tomo.guis.material;

import tomorrow.tomo.utils.math.AnimationUtils;

public class Tab {
    public String name;
    public float x = 0;
    public AnimationUtils animationUtils = new AnimationUtils();

    public void render(float mouseX, float mouseY) {

    }

    public void mouseClicked(float mouseX, float mouseY) {

    }
}
